
#include "project.h"
#include "stdio.h"
#include <stdlib.h>
#include <math.h>
// VARIABLES DE TECLADO
uint16 P_teclado;
uint16 P_teclado1;
uint16 P_teclado2;
uint16 a;
uint16 e;
/* Variables del control de direccion
viendo los cables soldados al motor, la tierra es cable blanco con naranja
fasea cable cafe con blanco
faseb cable azul con blanco
fasec cable naranja con blanco
*/
uint32 contador=0; // este tio mide la velocidad contando numero de ciclos dentro de un while 
int32 velocidad=0; // convierte del contador a velocidad            
//funciones de direccion
uint16 M1;
uint16 M2;
uint16 Periodo = 0;
uint16 tiempoReposoMotores =800;

void PWM(){
        Motor1_Write(M1);
        Motor2_Write(M2);
        CyDelayUs(tiempoReposoMotores);
        Motor1_Write(0);
        Motor2_Write(0);
        CyDelayUs(tiempoReposoMotores);
}
  /*INTERRUPCION PARA EL TECLADO*/  
CY_ISR(matrix){

TECLADO_IN_ClearInterrupt();
}
  /*INTERRUPCION PARA LOS CONTROLES*/
CY_ISR(detectarfase1){
    int fase=detectorFaseM1_Read();
    //fase=fase && 0b001;
    contador=0;
    velocidad=0;
    if (fase==0b001 || fase==0b110)
    {
        while(fase==0b001 || fase==0b110){
            fase=detectorFaseM1_Read();
            contador++;
        }
        if(fase==0b101 || fase==0b010)
        {
            sentidodegiroM1_Write(0b10);
        }
        else{
            if(fase==0b011 || fase==0b100 )
            {
                sentidodegiroM1_Write(0b01);
            }    
        }
        velocidad=(-17*contador+1070000)/10000;
    }
    CyDelay(20);
    LED_Write(1);
    sentidodegiroM1_Write(0b00);
detectorFaseM1_ClearInterrupt();
}
CY_ISR(detectarfase2){
    int fase=detectorFaseM2_Read();
    //fase=fase && 0b001;
    contador=0;
    velocidad=0;
    if (fase==0b001 || fase==0b110)
    {
        while(fase==0b001 || fase==0b110){
            fase=detectorFaseM1_Read();
            contador++;
        }
        if(fase==0b101 || fase==0b010)
        {
            sentidodegiroM2_Write(0b10);
        }
        else{
            if(fase==0b011 || fase==0b100 )
            {
                sentidodegiroM2_Write(0b01);
            }    
        }
        velocidad=(-17*contador+1070000)/10000;
    }
    CyDelay(20);
    LED_Write(1);
    sentidodegiroM2_Write(0b00);
detectorFaseM2_ClearInterrupt();
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    up_StartEx(matrix);
    faseM1_StartEx(detectarfase1);
    faseM2_StartEx(detectarfase2);
    PWM1_Start();
    PWM2_Start();

    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    Periodo = (2*16000/tiempoReposoMotores);
    Motor1_Write(0);
    Motor2_Write(0);
    a = Periodo;
    uint16 p1 = 3000;
    PWM1_WritePeriod(p1);
    PWM1_WriteCompare(p1/2);
    for(;;)
    {
        if(p1<=33000){ p1=25;}
        p1++;
       //PWM_WritePeriod(p);
        CyDelay(3000);
        /* Place your application code here. 
        while (a<Periodo){
            PWM();
            a++;

        }
        if(a==Periodo){
            //LED_Write(1);
        }*/
    

    }
}

/* [] END OF FILE */
