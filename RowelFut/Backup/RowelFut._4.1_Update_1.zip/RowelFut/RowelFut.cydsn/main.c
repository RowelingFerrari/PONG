#include "project.h"
#include "stdio.h"
#include <stdlib.h>
#include <math.h>
// VARIABLES DE TECLADO
uint16 P_teclado;
uint16 P_teclado1;
uint16 P_teclado2;
uint16 a;
uint16 e;
/* Variables del control de direccion
viendo los cables soldados al motor, la tierra es cable blanco con naranja
fasea cable cafe con blanco
faseb cable azul con blanco
fasec cable naranja con blanco
*/
uint32 contador=0; // este tio mide la velocidad contando numero de ciclos dentro de un while 
int32 velocidad=0; // convierte del contador a velocidad            
//funciones de direccion
uint16 M1;
uint16 M2;
uint16 Periodo = 0;
uint16 tiempoReposoMotores =800;

void PWM(){
        Motor1_Write(M1);
        Motor2_Write(M2);
        CyDelayUs(tiempoReposoMotores);
        Motor1_Write(0);
        Motor2_Write(0);
        CyDelayUs(tiempoReposoMotores);
}
  /*INTERRUPCION PARA EL TECLADO*/  
CY_ISR(matrix){
    LED_Write(1);
    P_teclado=teclado_Read();
    if(P_teclado2!=P_teclado){
        if(a>=Periodo){
            
            //P_teclado=teclado_Status;
            //a = teclado_Read();
            CyDelay(250);
            P_teclado1=teclado_Read();
            if(P_teclado==P_teclado1){
                P_teclado2=P_teclado;
                if(a==Periodo){a=0;}
                if (P_teclado<=9){
                    switch (P_teclado){
                        case 0:
                            M1=0;
                            M2=0;
                        break;
                        case 1:
                            M1=0;
                            M2=3;
                        break;
                        case 2:
                            M1=1;
                            M2=3;
                        break;
                        case 3:
                            M1=1;
                            M2=0;
                        break;
                        case 4:
                            M1=3;
                            M2=3;
                        break;
                        case 5:
                            M1=0;
                            M2=0;
                        break;
                        case 6:
                            M1=1;
                            M2=1;
                        break;
                        case 7:
                            M1=3;
                            M2=0;
                        break;
                        case 8:
                            M1=3;
                            M2=1;
                        break;
                        case 9:
                            M1=0;
                            M2=1;
                        break;
                    }
                }
            }
            CyDelay(100);
        }
    }else{a=0;}
LED_Write(0);
TECLADO_IN_ClearInterrupt();
}
  /*INTERRUPCION PARA LOS CONTROLES*/
CY_ISR(detectarfase){
    int fase=pfa_Read();
    //fase=fase && 0b001;
    contador=0;
    velocidad=0;
    if (fase==0b001 || fase==0b110)
    {
        while(fase==0b001 || fase==0b110){
            fase=pfa_Read();
            contador++;
        }
        if(fase==0b101 || fase==0b010)
        {
            sentidodegiro_Write(0b10);
        }
        else{
            if(fase==0b011 || fase==0b100 )
            {
                sentidodegiro_Write(0b01);
            }    
        }
        velocidad=(-17*contador+1070000)/10000;
    }
    CyDelay(20);
    LED_Write(1);
    sentidodegiro_Write(0b00);
pfa_ClearInterrupt();
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    up_StartEx(matrix);
    fase_StartEx(detectarfase);
    PWM_Start();
    PWM_1_Start();

    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    Periodo = (2*16000/tiempoReposoMotores);
    Motor1_Write(0);
    Motor2_Write(0);
    a = Periodo;
    uint16 p = 33000;
    PWM_WritePeriod(p);
    PWM_WriteCompare(p/2);
    for(;;)
    {
        if(p<=33000){ p=25;}
        p++;
       //PWM_WritePeriod(p);
        CyDelay(3000);
        /* Place your application code here. 
        while (a<Periodo){
            PWM();
            a++;

        }
        if(a==Periodo){
            //LED_Write(1);
        }*/
    

    }
}

/* [] END OF FILE */
